## 1.0 (November 14, 2017)

Dataset released. Bong rips and blunts all around!

This dataset is a culmination of years of research and accumulation of information across countless sources. As I discover more, they'll be integrated here.

### Brands

Added 1778 brands with fairly minimal columns (name, slug, location, category, Instagram username).

### Products

Added 17233 products. Uses brand name, not brand slug (needs change). Contains some external links to lab results, to be scrubbed later for relational index to our own lab result DB.

### Shops

Added 2880 shops (dispensaries, rec shops, headshops) across the entire USA. Most images/avatars link to placeholders for time being. Some addresses need to be re-geolocated to fill out other columns (state, city, etc).

### Strains

Added 9524 strains. Effects, ailments, flavor, type filled out. Some dupes need to be handled.